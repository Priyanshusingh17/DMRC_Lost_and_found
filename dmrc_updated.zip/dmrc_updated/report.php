<?php include __DIR__ . '/includes/header.php'; include __DIR__ . '/config/db.php';

// Fetch stations
$stations = [];
$res = $conn->query("SELECT id, name FROM stations ORDER BY name");
while ($row = $res->fetch_assoc()) { $stations[] = $row; }

$flash = $_GET['ok'] ?? '';
?>
<h2>Report Lost/Found Item</h2>
<?php if ($flash==='1'): ?>
  <div class="alert success">Report submitted! It will appear after admin approval.</div>
<?php endif; ?>
<form method="post" action="submit_report.php" enctype="multipart/form-data">
  <div class="form-row">
    <div>
      <label>Type</label>
      <select name="type" class="input" required>
        <option value="lost">Lost</option>
        <option value="found">Found</option>
      </select>
    </div>
    <div>
      <label>Station</label>
      <select name="station_id" class="input" required>
        <option value="">Select Station</option>
        <?php foreach ($stations as $st): ?>
          <option value="<?php echo $st['id']; ?>"><?php echo htmlspecialchars($st['name']); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
  <div class="form-row">
    <div>
      <label>Title</label>
      <input class="input" type="text" name="title" placeholder="e.g., Black backpack" required>
    </div>
    <div>
      <label>Date (approx.)</label>
      <input class="input" type="date" name="date" required>
    </div>
  </div>
  <label>Description</label>
  <textarea class="input" name="description" rows="4" placeholder="Describe the item and details" required></textarea>
  <div class="form-row">
    <div>
      <label>Your Name</label>
      <input class="input" type="text" name="contact_name" required>
    </div>
    <div>
      <label>Phone</label>
      <input class="input" type="text" name="contact_phone" required>
    </div>
  </div>
  <label>Upload Image (optional)</label>
  <input class="input" type="file" name="image">
  <br><br>
  <button class="btn" type="submit">Submit Report</button>
</form>
<?php include __DIR__ . '/includes/footer.php'; ?>
