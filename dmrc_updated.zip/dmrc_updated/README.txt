DELHI METRO LOST & FOUND (PHP + MySQL)
-----------------------------------------
Setup (XAMPP):
1) Copy 'delhi_metro_lostfound' to C:\xampp\htdocs\delhi_metro_lostfound
2) Start Apache + MySQL
3) Open phpMyAdmin -> Import -> select schema.sql (inside folder)
4) Visit: http://localhost/delhi_metro_lostfound/
5) Report page: http://localhost/delhi_metro_lostfound/report.php
6) Admin: http://localhost/delhi_metro_lostfound/admin/login.php

Default Admin: created automatically on first admin login page load
- Email: admin@example.com
- Password: Admin@123

Notes:
- Images uploaded go to /uploads
- Admin can approve/reject reports from Dashboard
- Public listing shows only approved reports
