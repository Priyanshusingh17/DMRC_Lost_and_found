<?php
header("Location: /delhi_metro_lostfound/admin/dashboard.php");
exit;
?>