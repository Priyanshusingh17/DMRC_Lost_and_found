<?php
include __DIR__ . '/config/db.php';

function sanitize($s){ return trim($s); }

$type = $_POST['type'] ?? '';
$station_id = intval($_POST['station_id'] ?? 0);
$title = sanitize($_POST['title'] ?? '');
$date = $_POST['date'] ?? '';
$description = sanitize($_POST['description'] ?? '');
$contact_name = sanitize($_POST['contact_name'] ?? '');
$contact_phone = sanitize($_POST['contact_phone'] ?? '');

if(!$type || !$station_id || !$title || !$date || !$description || !$contact_name || !$contact_phone){
  header("Location: report.php?ok=0");
  exit;
}

// Handle upload
$image_path = NULL;
if (!empty($_FILES['image']['name'])) {
    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $fname = uniqid('img_', true) . '.' . preg_replace('/[^a-zA-Z0-9]/','',$ext);
    $target = __DIR__ . '/uploads/' . $fname;
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $image_path = 'uploads/' . $fname;
    }
}

$stmt = $conn->prepare("INSERT INTO reports (type, station_id, title, description, date, image_path, contact_name, contact_phone, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
$stmt->bind_param("sissssss", $type, $station_id, $title, $description, $date, $image_path, $contact_name, $contact_phone);
$stmt->execute();

header("Location: report.php?ok=1");
exit;
