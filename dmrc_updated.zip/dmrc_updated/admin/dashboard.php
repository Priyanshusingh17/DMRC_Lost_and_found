<?php
session_start();
if(!isset($_SESSION['admin_loggedin'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="navbar">
    <a href="../index.php">Home</a>
    <a href="../report.php">Report</a>
    <a href="dashboard.php">Dashboard</a>
    <a href="logout.php">Logout</a>
</div>

<h2 class="page-heading">Admin Dashboard</h2>

<div class="dashboard">
    <div class="card">
        <h3>Total Reports</h3>
        <p>120</p>
    </div>
    <div class="card">
        <h3>Pending Approvals</h3>
        <p>15</p>
    </div>
    <div class="card">
        <h3>Approved Items</h3>
        <p>95</p>
    </div>
</div>
</body>
</html>
