-- Database schema for DMRC Lost & Found
CREATE DATABASE IF NOT EXISTS dmrc_lostfound CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE dmrc_lostfound;

-- users (admins)
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin') NOT NULL DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- stations
CREATE TABLE IF NOT EXISTS stations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(190) NOT NULL,
  line VARCHAR(100) DEFAULT NULL
);

-- reports
CREATE TABLE IF NOT EXISTS reports (
  id INT AUTO_INCREMENT PRIMARY KEY,
  type ENUM('lost','found') NOT NULL,
  station_id INT NOT NULL,
  title VARCHAR(190) NOT NULL,
  description TEXT NOT NULL,
  date DATE NOT NULL,
  image_path VARCHAR(255) DEFAULT NULL,
  contact_name VARCHAR(100) NOT NULL,
  contact_phone VARCHAR(30) NOT NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE RESTRICT
);

-- seed stations (popular subset; extend as needed)
INSERT INTO stations (name,line) VALUES
('Rajiv Chowk','Blue/Yellow'),
('Kashmere Gate','Red/Yellow/Violet'),
('Hauz Khas','Magenta/Yellow'),
('Dwarka Mor','Blue'),
('Noida City Centre','Blue'),
('Vaishali','Blue'),
('Botanical Garden','Blue/Magenta'),
('Central Secretariat','Yellow/Violet'),
('AIIMS','Yellow'),
('Chandni Chowk','Yellow');

-- Note: admin user is auto-seeded on first /admin/login.php visit.
