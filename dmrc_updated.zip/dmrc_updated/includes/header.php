<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Delhi Metro Lost & Found</title>
  <link rel="stylesheet" href="/delhi_metro_lostfound/assets/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="container nav">
    <a href="/delhi_metro_lostfound/index.php" class="logo">DMRC Lost & Found</a>
    <nav>
      <a href="/delhi_metro_lostfound/index.php">Home</a>
      <a href="/delhi_metro_lostfound/report.php">Report</a>
      <a href="/delhi_metro_lostfound/admin/login.php">Admin</a>
    </nav>
  </div>
</header>
<main class="container">
