<?php
include __DIR__ . '/../config/db.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }

$id = intval($_POST['id'] ?? 0);
$action = $_POST['action'] ?? '';
if ($id && in_array($action,['approve','reject'])) {
    $status = $action==='approve' ? 'approved' : 'rejected';
    $stmt = $conn->prepare("UPDATE reports SET status=? WHERE id=?");
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();
}
header("Location: dashboard.php");
exit;
