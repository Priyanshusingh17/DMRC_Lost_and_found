<?php
include __DIR__ . '/../config/db.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// seed default admin if none
$res = $conn->query("SELECT COUNT(*) AS c FROM users WHERE role='admin'");
$row = $res->fetch_assoc();
if (intval($row['c']) === 0) {
    $email = 'admin@example.com';
    $pass = password_hash('Admin@123', PASSWORD_DEFAULT);
    $conn->query("INSERT INTO users (email,password,role) VALUES ('$email','$pass','admin')");
}

$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $stmt = $conn->prepare("SELECT id, password FROM users WHERE email=? AND role='admin' LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows===1) {
        $u = $res->fetch_assoc();
        if (password_verify($password, $u['password'])) {
            $_SESSION['admin_id'] = $u['id'];
            header("Location: dashboard.php");
            exit;
        }
    }
    $error = 'Invalid credentials';
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="/delhi_metro_lostfound/assets/css/style.css"><title>Admin Login</title></head>
<body><div class="container" style="max-width:480px;margin-top:60px">
  <h2>Admin Login</h2>
  <?php if ($error): ?><div class="alert error"><?php echo $error; ?></div><?php endif; ?>
  <form method="post">
    <label>Email</label>
    <input class="input" type="email" name="email" value="admin@example.com" required>
    <label>Password</label>
    <input class="input" type="password" name="password" value="Admin@123" required>
    <br><button class="btn" type="submit">Login</button>
  </form>
</div></body></html>
