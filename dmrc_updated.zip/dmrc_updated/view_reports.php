<?php
include("config/db.php"); // make sure db.php connects correctly

// Fetch approved "found" items
$query = "SELECT r.*, s.name AS station_name, s.line AS station_line 
          FROM reports r 
          JOIN stations s ON r.station_id = s.id 
          WHERE r.status='approved' AND r.type='found'
          ORDER BY r.date DESC";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Found Items</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header>
  <img src="assets/images/delhi_metro_logo.png" alt="Delhi Metro Logo">
  <h1>Delhi Metro Lost & Found</h1>
</header>

<div class="container">
  <h2>Found Items</h2>
  <?php if(mysqli_num_rows($result) > 0) { 
      while($row = mysqli_fetch_assoc($result)) { ?>
        <div class="card">
          <h3><?php echo htmlspecialchars($row['title']); ?></h3>
          <p><b>Description:</b> <?php echo htmlspecialchars($row['description']); ?></p>
          <p><b>Date Found:</b> <?php echo htmlspecialchars($row['date']); ?></p>
          <p><b>Station:</b> <?php echo htmlspecialchars($row['station_name']); ?> (<?php echo htmlspecialchars($row['station_line']); ?>)</p>
          <p><b>Contact:</b> <?php echo htmlspecialchars($row['contact_name']); ?> - <?php echo htmlspecialchars($row['contact_phone']); ?></p>

          <?php 
          // ✅ Safe image path handling
          if(!empty($row['image_path'])) {
              $image = $row['image_path'];
              if(strpos($image, 'uploads/') === false) {
                  $image = "uploads/" . $image;
              }
              echo '<img src="'.htmlspecialchars($image).'" alt="Item Image">';
          }
          ?>
        </div>
  <?php } } else { ?>
      <p>No approved found items yet.</p>
  <?php } ?>
</div>
</body>
</html>
